# Auto Scroll BD

Automatic scrolling for [KOReader](https://github.com/koreader/koreader) with adjustable speed, persistent settings, and gesture/dispatcher controls.

**Created by Argho Rahamatullah.**

## Features

- Start and stop automatic scrolling from the KOReader menu.
- Works with KOReader Continuous / Scroll mode.
- Adjustable scrolling speed from the plugin menu.
- Speed is remembered across KOReader restarts.
- Dispatcher actions for gesture/button assignment:
  - **Auto Scroll BD: Start / Stop**
  - **Auto Scroll BD: Speed +5**
  - **Auto Scroll BD: Speed -5**
- Stops automatically if the document is closed or Scroll mode is disabled.
- Designed for e-ink readers where simple, low-overhead scrolling is useful.

## Requirements

- KOReader with plugin support.
- A document opened in **Continuous / Scroll** mode.

## Installation

### Manual installation

1. Download or clone this repository.
2. Copy the `auto_scroll_bd.koplugin` folder into your KOReader `plugins` directory.
3. Restart KOReader.
4. Open a book and enable **Continuous / Scroll** mode.
5. Open **Tools → Auto Scroll BD** and choose **Start scrolling**.

The directory must keep the `.koplugin` suffix:

```text
koreader/
└── plugins/
    └── auto_scroll_bd.koplugin/
        ├── _meta.lua
        └── main.lua
```

## Gesture controls

Auto Scroll BD registers its controls with KOReader's Dispatcher. To assign gestures:

1. Open KOReader's gesture settings while reading.
2. Choose the gesture you want to configure.
3. Select one of the Auto Scroll BD actions.

The plugin itself does not hard-code a particular gesture, so users can choose gestures that fit their device and existing KOReader setup.

## Speed

The selected speed is stored in KOReader's settings directory and restored automatically the next time the plugin loads.

Menu presets range from **1 to 60 px/s**. The gesture actions change the current speed by **5 px/s**, with limits of **1–60 px/s**.

## Compatibility

Auto Scroll BD is intended for current KOReader versions and may need adjustments if KOReader changes its scrolling or Dispatcher APIs.

If a KOReader update breaks the plugin, please open an issue with:

- KOReader version / build
- device model
- a description of what happened
- relevant KOReader crash/log output, if available

## Development

This repository is the upstream project for the plugin. The KOReader `contrib` repository is intended for working community plugins and asks each plugin to point to an upstream Git repository.

## License

GNU Affero General Public License v3.0. See [LICENSE](LICENSE).

return {
    name = "auto_scroll_bd",
    fullname = "Auto Scroll BD",
    description = "Automatic scrolling for KOReader with adjustable speed and gesture/dispatcher controls.",
    version = "1.0.0",
    author = "Argho Rahamatullah",
}

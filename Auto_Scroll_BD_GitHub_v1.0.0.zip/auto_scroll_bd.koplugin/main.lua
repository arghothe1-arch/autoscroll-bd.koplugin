local DataStorage = require("datastorage")
local Dispatcher = require("dispatcher")
local Event = require("ui/event")
local LuaSettings = require("luasettings")
local UIManager = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local InfoMessage = require("ui/widget/infomessage")
local _ = require("gettext")


local AutoScroll = WidgetContainer:extend{

    name = "auto_scroll_bd",

    is_doc_only = true,

    settings_file =
        DataStorage:getSettingsDir()
        .. "/autoscroll.lua",

    running = false,

    speed = 10,

    -- 20 updates per second
    interval = 0.05,
}


function AutoScroll:init()

    self.settings =
        LuaSettings:open(self.settings_file)

    self.speed = tonumber(
        self.settings:readSetting("speed")
    ) or 10

    self.scrollTick = function()
        self:doScroll()
    end

    -- Register gesture/dispatcher actions
    self:onDispatcherRegisterActions()

    -- Register main menu
    self.ui.menu:registerToMainMenu(self)
end


----------------------------------------------------------------
-- DISPATCHER / GESTURE ACTIONS
----------------------------------------------------------------

function AutoScroll:onDispatcherRegisterActions()

    -- Start / Stop
    Dispatcher:registerAction(
        "auto_scroll_bd_toggle",
        {
            category = "none",
            event = "AutoScrollToggle",
            title = _("Auto Scroll BD: Start / Stop"),
            reader = true,
        }
    )


    -- Speed +5
    Dispatcher:registerAction(
        "auto_scroll_bd_speed_up",
        {
            category = "none",
            event = "AutoScrollSpeedUp",
            title = _("Auto Scroll BD: Speed +5"),
            reader = true,
        }
    )


    -- Speed -5
    Dispatcher:registerAction(
        "auto_scroll_bd_speed_down",
        {
            category = "none",
            event = "AutoScrollSpeedDown",
            title = _("Auto Scroll BD: Speed -5"),
            reader = true,
        }
    )
end


function AutoScroll:onAutoScrollToggle()

    if self.running then
        self:stop()
    else
        self:start()
    end
end


function AutoScroll:onAutoScrollSpeedUp()

    local new_speed =
        math.min(
            60,
            self.speed + 5
        )

    self:setSpeed(new_speed)

    self:showSpeedMessage()
end


function AutoScroll:onAutoScrollSpeedDown()

    local new_speed =
        math.max(
            1,
            self.speed - 5
        )

    self:setSpeed(new_speed)

    self:showSpeedMessage()
end


function AutoScroll:showSpeedMessage()

    UIManager:show(
        InfoMessage:new{
            text = string.format(
                _("Auto Scroll BD: %d px/s"),
                self.speed
            ),
            timeout = 1,
        }
    )
end


----------------------------------------------------------------
-- MAIN MENU
----------------------------------------------------------------

function AutoScroll:addToMainMenu(menu_items)

    menu_items.autoscroll = {

        text = _("Auto Scroll BD"),

        sub_item_table_func = function()
            return self:getMenuItems()
        end,
    }
end


function AutoScroll:getMenuItems()

    local items = {}


    -- Start / Stop
    table.insert(items, {

        text = self.running
            and _("Stop scrolling")
            or _("Start scrolling"),

        callback = function()

            if self.running then
                self:stop()
            else
                self:start()
            end

        end,
    })


    ------------------------------------------------------------
    -- SPEED MENU
    ------------------------------------------------------------

    local speed_menu = {

        text = _("Speed"),

        sub_item_table = {},
    }


    -- Practical speed presets. Gesture controls can still adjust
    -- the speed one step at a time between 1 and 60 px/s.
    local speeds = { 1, 2, 3, 5, 8, 10, 12, 15, 20, 25, 30, 40, 50, 60 }

    for _, speed in ipairs(speeds) do

        table.insert(
            speed_menu.sub_item_table,
            {

                text = string.format(
                    "%d px/s",
                    speed
                ),

                radio = true,

                checked_func = function()

                    return self.speed == speed

                end,

                callback = function()

                    self:setSpeed(speed)

                end,
            }
        )

    end


    table.insert(
        items,
        speed_menu
    )


    ------------------------------------------------------------
    -- GESTURE CONTROLS
    ------------------------------------------------------------

    table.insert(items, {
        text = _("Gesture controls"),
        callback = function()
            UIManager:show(
                InfoMessage:new{
                    text = _([[Assign these actions in KOReader gesture settings:

• Auto Scroll BD: Start / Stop
• Auto Scroll BD: Speed +5
• Auto Scroll BD: Speed -5

The actions are available as dispatcher actions whenever a book is open.]]),
                    timeout = 6,
                }
            )
        end,
    })


    ------------------------------------------------------------
    -- CURRENT SPEED
    ------------------------------------------------------------

    table.insert(items, {

        text = string.format(
            _("Current speed: %d px/s"),
            self.speed
        ),

        enabled_func = function()
            return false
        end,
    })


    return items
end


----------------------------------------------------------------
-- SPEED
----------------------------------------------------------------

function AutoScroll:setSpeed(speed)

    speed = math.max(
        1,
        math.min(
            60,
            tonumber(speed) or self.speed
        )
    )

    self.speed = speed

    self.settings:saveSetting(
        "speed",
        speed
    )

    self.settings:flush()
end


----------------------------------------------------------------
-- START
----------------------------------------------------------------

function AutoScroll:start()

    if self.running then
        return
    end


    if not self.ui.document then

        UIManager:show(
            InfoMessage:new{
                text = _("Open a book first."),
                timeout = 2,
            }
        )

        return
    end


    if not self.ui.view
        or self.ui.view.view_mode ~= "scroll" then

        UIManager:show(
            InfoMessage:new{
                text =
                    _("Please enable Continuous / Scroll mode first."),
                timeout = 3,
            }
        )

        return
    end


    self.running = true

    self:scheduleNext()
end


----------------------------------------------------------------
-- SCHEDULER
----------------------------------------------------------------

function AutoScroll:scheduleNext()

    if not self.running then
        return
    end


    UIManager:unschedule(
        self.scrollTick
    )


    UIManager:scheduleIn(
        self.interval,
        self.scrollTick
    )
end


----------------------------------------------------------------
-- SCROLL
----------------------------------------------------------------

function AutoScroll:doScroll()

    if not self.running then
        return
    end


    if not self.ui
        or not self.ui.document then

        self:stop()

        return
    end


    if not self.ui.view
        or self.ui.view.view_mode ~= "scroll" then

        self:stop()

        UIManager:show(
            InfoMessage:new{
                text =
                    _("Auto Scroll stopped: Scroll mode is no longer active."),
                timeout = 2,
            }
        )

        return
    end


    local normal_step =
        self.ui.rolling
        and self.ui.rolling.panning_steps
        and self.ui.rolling.panning_steps.normal


    if not normal_step then
        normal_step = 50
    end


    -- Convert px/s to movement for this tick
    local distance =
        self.speed * self.interval


    local dy =
        distance / normal_step


    self.ui:handleEvent(
        Event:new(
            "Panning",
            { 0, dy }
        )
    )


    self:scheduleNext()
end


----------------------------------------------------------------
-- STOP
----------------------------------------------------------------

function AutoScroll:stop()

    self.running = false

    UIManager:unschedule(
        self.scrollTick
    )
end


----------------------------------------------------------------
-- CLEANUP
----------------------------------------------------------------

function AutoScroll:onCloseWidget()

    self:stop()
end


return AutoScroll
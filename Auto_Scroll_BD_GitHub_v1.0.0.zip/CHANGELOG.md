# Changelog

## 1.0.0 - 2026-10-04

- Initial public release of Auto Scroll BD.
- Added adjustable automatic scrolling.
- Added persistent speed settings.
- Added KOReader Dispatcher actions for start/stop and speed adjustment.
- Added documentation for gesture assignment.
- Added plugin metadata and creator attribution.
